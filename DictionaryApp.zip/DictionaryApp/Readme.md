#Install by clicking the MyDictionary.exe file

API used: https://www.dictionaryapi.com/ (Miriam Webster);
Built with C#(.NET Framework)